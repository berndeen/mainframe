# shadcn/ui — Pattern Analysis for Skill Suite v4.4

## Core Philosophy

shadcn/ui is NOT a component library — it's a code distribution platform. Key principles:

1. **Open Code / Copy-Don't-Install** — Users get actual source code, not npm dependencies. Full ownership. No version conflicts. No abandoned packages breaking builds.
2. **Composable Interface** — Every component shares a common, predictable API. New components are brought in, made composable, styled to match.
3. **Flat-File Schema + Registry** — Components defined via JSON schemas (`registry.json`, `registry-item.json`). CLI distributes them across projects and frameworks.
4. **Beautiful Defaults** — Great out-of-the-box design, but fully overridable.
5. **AI-Ready** — Open code means LLMs can read, understand, and generate components based on existing schema.

## Registry System

### registry.json (top-level)
```json
{
  "$schema": "https://ui.shadcn.com/schema/registry.json",
  "name": "acme",
  "homepage": "https://acme.com",
  "items": [...]
}
```

### registry-item.json (per-component)
```json
{
  "name": "unique-id",
  "title": "Human Title",
  "description": "...",
  "type": "registry:component | registry:ui | registry:hook | registry:lib | registry:block | registry:page | registry:theme | registry:style | registry:font | registry:file | registry:base | registry:item",
  "dependencies": { "npm-package": "@version" },
  "devDependencies": { "npm-dev-package": "@version" },
  "registryDependencies": ["button", "@acme/input-form", "https://example.com/r/item.json"],
  "files": [{ "path": "...", "type": "...", "target": "..." }],
  "categories": ["..."],
  "author": "...",
  "docs": "Custom message for CLI install",
  "meta": {}
}
```

### CLI Commands
- `init` — Initialize project with config + dependencies
- `add` — Add components from registry
- `view` — Preview before installing
- `search` — Browse registries
- `build` — Generate registry JSON from `registry.json`

### Namespaced Registries (v3+)
Private/community registries via namespace: `@acme/component-name`. Auth via API keys. Any project type, any framework.

## Patterns Applicable to Our Skill Suite

### 1. Skill Registry System (High Priority)
**shadcn pattern:** Flat-file schema + CLI for component distribution
**Our equivalent:** Formalize skill packaging with a `skill.json` manifest — name, version, dependencies, tier compatibility, entry point, collision strategy

Currently our skills are ad-hoc markdown files with YAML frontmatter. shadcn's registry model shows how to formalize this into:
- A schema that defines what a skill IS (type, dependencies, files, metadata)
- A distribution mechanism (CLI or platform-level)
- Dependency resolution between skills (Brain depends-on ExecDev)
- Versioning with semantic version constraints

### 2. Copy-Don't-Install Ownership Model (Already Implemented)
**shadcn pattern:** Users own the source code, not a dependency
**Our equivalent:** Our skills ARE already copy-don't-install — they're markdown files that get loaded and modified. The Brain explicitly says "not a package."

This is a validation of our approach, not a gap. shadcn proves this model scales.

### 3. Composable Interface / Shared API (Medium Priority)
**shadcn pattern:** Every component shares a common composable interface
**Our equivalent:** Our skills share philosophical alignment but not a formal interface contract. Brain, ExecDev, PIE each have their own structure. 

Should we formalize: common frontmatter schema, common section structure (routing → core → modules → shared), common governance hooks?

### 4. Registry Types for Different Artifact Classes (Medium Priority)
**shadcn pattern:** registry:component, registry:hook, registry:ui, registry:page, etc.
**Our equivalent:** We could define skill types: `skill:governance`, `skill:architecture`, `skill:implementation`, `skill:reference`, `skill:template`, `skill:audit`

### 5. AI-Ready Design (Already Implemented)
**shadcn pattern:** Open code for LLMs to read/understand/generate
**Our equivalent:** Our skills are explicitly designed for LLM consumption. The modular routing, lossless compression protocol, and clear section boundaries are all AI-ready patterns.

### 6. Beautiful Defaults with Override (Opportunity)
**shadcn pattern:** Works great out of the box, fully customizable
**Our equivalent:** Our skills work well with defaults (e.g., Brain defaults to T1-Super), but the "customization" story is ad-hoc. Should we formalize: default configurations, override points, and how to specialize a skill for a specific domain?
